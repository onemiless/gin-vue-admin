// 自动生成模板COPMA
package alpha

import (
	
	
	
)

// COPMA表 结构体  COPMA
type COPMA struct {

      COMPANY  string `json:"COMPANY" form:"COMPANY" gorm:"column:COMPANY;comment:;size:10;"`  //COMPANY字段 
      CREATOR  string `json:"CREATOR" form:"CREATOR" gorm:"column:CREATOR;comment:;size:10;"`  //CREATOR字段 
      USRGROUP  string `json:"USRGROUP" form:"USRGROUP" gorm:"column:USR_GROUP;comment:;size:10;"`  //USRGROUP字段 
      CREATEDATE  string `json:"CREATEDATE" form:"CREATEDATE" gorm:"column:CREATE_DATE;comment:;size:17;"`  //CREATEDATE字段 
      MODIFIER  string `json:"MODIFIER" form:"MODIFIER" gorm:"column:MODIFIER;comment:;size:10;"`  //MODIFIER字段 
      MODIDATE  string `json:"MODIDATE" form:"MODIDATE" gorm:"column:MODI_DATE;comment:;size:17;"`  //MODIDATE字段 
      FLAG  *float64 `json:"FLAG" form:"FLAG" gorm:"column:FLAG;comment:;"`  //FLAG字段 
      MA001  string `json:"MA001" form:"MA001" gorm:"primarykey;column:MA001;comment:;size:10;"`  //MA001字段 
      MA002  string `json:"MA002" form:"MA002" gorm:"column:MA002;comment:;size:20;"`  //MA002字段 
      MA003  string `json:"MA003" form:"MA003" gorm:"column:MA003;comment:;size:72;"`  //MA003字段 
      MA004  string `json:"MA004" form:"MA004" gorm:"column:MA004;comment:;size:30;"`  //MA004字段 
      MA005  string `json:"MA005" form:"MA005" gorm:"column:MA005;comment:;size:30;"`  //MA005字段 
      MA006  string `json:"MA006" form:"MA006" gorm:"column:MA006;comment:;size:20;"`  //MA006字段 
      MA007  string `json:"MA007" form:"MA007" gorm:"column:MA007;comment:;size:20;"`  //MA007字段 
      MA008  string `json:"MA008" form:"MA008" gorm:"column:MA008;comment:;size:20;"`  //MA008字段 
      MA009  string `json:"MA009" form:"MA009" gorm:"column:MA009;comment:;size:255;"`  //MA009字段 
      MA010  string `json:"MA010" form:"MA010" gorm:"column:MA010;comment:;size:20;"`  //MA010字段 
      MA011  *float64 `json:"MA011" form:"MA011" gorm:"column:MA011;comment:;"`  //MA011字段 
      MA012  *float64 `json:"MA012" form:"MA012" gorm:"column:MA012;comment:;"`  //MA012字段 
      MA013  *float64 `json:"MA013" form:"MA013" gorm:"column:MA013;comment:;"`  //MA013字段 
      MA014  string `json:"MA014" form:"MA014" gorm:"column:MA014;comment:;size:4;"`  //MA014字段 
      MA015  string `json:"MA015" form:"MA015" gorm:"column:MA015;comment:;size:6;"`  //MA015字段 
      MA016  string `json:"MA016" form:"MA016" gorm:"column:MA016;comment:;size:10;"`  //MA016字段 
      MA017  string `json:"MA017" form:"MA017" gorm:"column:MA017;comment:;size:6;"`  //MA017字段 
      MA018  string `json:"MA018" form:"MA018" gorm:"column:MA018;comment:;size:6;"`  //MA018字段 
      MA019  string `json:"MA019" form:"MA019" gorm:"column:MA019;comment:;size:6;"`  //MA019字段 
      MA020  string `json:"MA020" form:"MA020" gorm:"column:MA020;comment:;size:8;"`  //MA020字段 
      MA021  string `json:"MA021" form:"MA021" gorm:"column:MA021;comment:;size:8;"`  //MA021字段 
      MA022  string `json:"MA022" form:"MA022" gorm:"column:MA022;comment:;size:8;"`  //MA022字段 
      MA023  string `json:"MA023" form:"MA023" gorm:"column:MA023;comment:;size:72;"`  //MA023字段 
      MA024  string `json:"MA024" form:"MA024" gorm:"column:MA024;comment:;size:72;"`  //MA024字段 
      MA025  string `json:"MA025" form:"MA025" gorm:"column:MA025;comment:;size:72;"`  //MA025字段 
      MA026  string `json:"MA026" form:"MA026" gorm:"column:MA026;comment:;size:72;"`  //MA026字段 
      MA027  string `json:"MA027" form:"MA027" gorm:"column:MA027;comment:;size:72;"`  //MA027字段 
      MA028  string `json:"MA028" form:"MA028" gorm:"column:MA028;comment:;size:1;"`  //MA028字段 
      MA029  string `json:"MA029" form:"MA029" gorm:"column:MA029;comment:;size:1;"`  //MA029字段 
      MA030  string `json:"MA030" form:"MA030" gorm:"column:MA030;comment:;size:16;"`  //MA030字段 
      MA031  string `json:"MA031" form:"MA031" gorm:"column:MA031;comment:;size:60;"`  //MA031字段 
      MA032  string `json:"MA032" form:"MA032" gorm:"column:MA032;comment:;size:1;"`  //MA032字段 
      MA033  *float64 `json:"MA033" form:"MA033" gorm:"column:MA033;comment:;"`  //MA033字段 
      MA034  *float64 `json:"MA034" form:"MA034" gorm:"column:MA034;comment:;"`  //MA034字段 
      MA035  string `json:"MA035" form:"MA035" gorm:"column:MA035;comment:;size:1;"`  //MA035字段 
      MA036  *float64 `json:"MA036" form:"MA036" gorm:"column:MA036;comment:;"`  //MA036字段 
      MA037  string `json:"MA037" form:"MA037" gorm:"column:MA037;comment:;size:1;"`  //MA037字段 
      MA038  string `json:"MA038" form:"MA038" gorm:"column:MA038;comment:;size:1;"`  //MA038字段 
      MA039  string `json:"MA039" form:"MA039" gorm:"column:MA039;comment:;size:1;"`  //MA039字段 
      MA040  string `json:"MA040" form:"MA040" gorm:"column:MA040;comment:;size:10;"`  //MA040字段 
      MA041  string `json:"MA041" form:"MA041" gorm:"column:MA041;comment:;size:4;"`  //MA041字段 
      MA042  string `json:"MA042" form:"MA042" gorm:"column:MA042;comment:;size:1;"`  //MA042字段 
      MA043  string `json:"MA043" form:"MA043" gorm:"column:MA043;comment:;size:2;"`  //MA043字段 
      MA044  *float64 `json:"MA044" form:"MA044" gorm:"column:MA044;comment:;"`  //MA044字段 
      MA045  *float64 `json:"MA045" form:"MA045" gorm:"column:MA045;comment:;"`  //MA045字段 
      MA046  string `json:"MA046" form:"MA046" gorm:"column:MA046;comment:;size:10;"`  //MA046字段 
      MA047  string `json:"MA047" form:"MA047" gorm:"column:MA047;comment:;size:20;"`  //MA047字段 
      MA048  string `json:"MA048" form:"MA048" gorm:"column:MA048;comment:;size:1;"`  //MA048字段 
      MA049  string `json:"MA049" form:"MA049" gorm:"column:MA049;comment:;size:255;"`  //MA049字段 
      MA050  string `json:"MA050" form:"MA050" gorm:"column:MA050;comment:;size:20;"`  //MA050字段 
      MA051  string `json:"MA051" form:"MA051" gorm:"column:MA051;comment:;size:20;"`  //MA051字段 
      MA052  string `json:"MA052" form:"MA052" gorm:"column:MA052;comment:;size:20;"`  //MA052字段 
      MA053  string `json:"MA053" form:"MA053" gorm:"column:MA053;comment:;size:20;"`  //MA053字段 
      MA054  string `json:"MA054" form:"MA054" gorm:"column:MA054;comment:;size:10;"`  //MA054字段 
      MA055  string `json:"MA055" form:"MA055" gorm:"column:MA055;comment:;size:10;"`  //MA055字段 
      MA056  string `json:"MA056" form:"MA056" gorm:"column:MA056;comment:;size:10;"`  //MA056字段 
      MA057  string `json:"MA057" form:"MA057" gorm:"column:MA057;comment:;size:10;"`  //MA057字段 
      MA058  string `json:"MA058" form:"MA058" gorm:"column:MA058;comment:;size:10;"`  //MA058字段 
      MA059  *float64 `json:"MA059" form:"MA059" gorm:"column:MA059;comment:;"`  //MA059字段 
      MA060  *float64 `json:"MA060" form:"MA060" gorm:"column:MA060;comment:;"`  //MA060字段 
      MA061  *float64 `json:"MA061" form:"MA061" gorm:"column:MA061;comment:;"`  //MA061字段 
      MA062  string `json:"MA062" form:"MA062" gorm:"column:MA062;comment:;size:72;"`  //MA062字段 
      MA063  string `json:"MA063" form:"MA063" gorm:"column:MA063;comment:;size:72;"`  //MA063字段 
      MA064  string `json:"MA064" form:"MA064" gorm:"column:MA064;comment:;size:72;"`  //MA064字段 
      MA065  string `json:"MA065" form:"MA065" gorm:"column:MA065;comment:;size:10;"`  //MA065字段 
      MA066  string `json:"MA066" form:"MA066" gorm:"column:MA066;comment:;size:1;"`  //MA066字段 
      MA067  *float64 `json:"MA067" form:"MA067" gorm:"column:MA067;comment:;"`  //MA067字段 
      MA068  string `json:"MA068" form:"MA068" gorm:"column:MA068;comment:;size:8;"`  //MA068字段 
      MA069  string `json:"MA069" form:"MA069" gorm:"column:MA069;comment:;size:10;"`  //MA069字段 
      MA070  string `json:"MA070" form:"MA070" gorm:"column:MA070;comment:;size:10;"`  //MA070字段 
      MA071  string `json:"MA071" form:"MA071" gorm:"column:MA071;comment:;size:30;"`  //MA071字段 
      MA072  string `json:"MA072" form:"MA072" gorm:"column:MA072;comment:;size:30;"`  //MA072字段 
      MA073  string `json:"MA073" form:"MA073" gorm:"column:MA073;comment:;size:30;"`  //MA073字段 
      MA074  string `json:"MA074" form:"MA074" gorm:"column:MA074;comment:;size:20;"`  //MA074字段 
      MA075  string `json:"MA075" form:"MA075" gorm:"column:MA075;comment:;size:10;"`  //MA075字段 
      MA076  string `json:"MA076" form:"MA076" gorm:"column:MA076;comment:;size:6;"`  //MA076字段 
      MA077  string `json:"MA077" form:"MA077" gorm:"column:MA077;comment:;size:6;"`  //MA077字段 
      MA078  string `json:"MA078" form:"MA078" gorm:"column:MA078;comment:;size:6;"`  //MA078字段 
      MA079  string `json:"MA079" form:"MA079" gorm:"column:MA079;comment:;size:10;"`  //MA079字段 
      MA080  string `json:"MA080" form:"MA080" gorm:"column:MA080;comment:;size:10;"`  //MA080字段 
      MA081  string `json:"MA081" form:"MA081" gorm:"column:MA081;comment:;size:10;"`  //MA081字段 
      MA082  string `json:"MA082" form:"MA082" gorm:"column:MA082;comment:;size:1;"`  //MA082字段 
      MA083  string `json:"MA083" form:"MA083" gorm:"column:MA083;comment:;size:6;"`  //MA083字段 
      MA084  string `json:"MA084" form:"MA084" gorm:"column:MA084;comment:;size:1;"`  //MA084字段 
      MA085  string `json:"MA085" form:"MA085" gorm:"column:MA085;comment:;size:10;"`  //MA085字段 
      MA086  string `json:"MA086" form:"MA086" gorm:"column:MA086;comment:;size:1;"`  //MA086字段 
      MA087  string `json:"MA087" form:"MA087" gorm:"column:MA087;comment:;size:1;"`  //MA087字段 
      MA088  string `json:"MA088" form:"MA088" gorm:"column:MA088;comment:;size:1;"`  //MA088字段 
      MA089  string `json:"MA089" form:"MA089" gorm:"column:MA089;comment:;size:1;"`  //MA089字段 
      MA090  *float64 `json:"MA090" form:"MA090" gorm:"column:MA090;comment:;"`  //MA090字段 
      MA091  *float64 `json:"MA091" form:"MA091" gorm:"column:MA091;comment:;"`  //MA091字段 
      MA092  *float64 `json:"MA092" form:"MA092" gorm:"column:MA092;comment:;"`  //MA092字段 
      MA093  *float64 `json:"MA093" form:"MA093" gorm:"column:MA093;comment:;"`  //MA093字段 
      MA094  *float64 `json:"MA094" form:"MA094" gorm:"column:MA094;comment:;"`  //MA094字段 
      MA095  *float64 `json:"MA095" form:"MA095" gorm:"column:MA095;comment:;"`  //MA095字段 
      MA096  string `json:"MA096" form:"MA096" gorm:"column:MA096;comment:;size:1;"`  //MA096字段 
      MA097  string `json:"MA097" form:"MA097" gorm:"column:MA097;comment:;size:1;"`  //MA097字段 
      MA098  string `json:"MA098" form:"MA098" gorm:"column:MA098;comment:;size:20;"`  //MA098字段 
      MA099  string `json:"MA099" form:"MA099" gorm:"column:MA099;comment:;size:20;"`  //MA099字段 
      MA100  string `json:"MA100" form:"MA100" gorm:"column:MA100;comment:;size:20;"`  //MA100字段 
      MA101  *float64 `json:"MA101" form:"MA101" gorm:"column:MA101;comment:;"`  //MA101字段 
      MA102  string `json:"MA102" form:"MA102" gorm:"column:MA102;comment:;size:20;"`  //MA102字段 
      MA103  string `json:"MA103" form:"MA103" gorm:"column:MA103;comment:;size:1;"`  //MA103字段 
      MA104  *float64 `json:"MA104" form:"MA104" gorm:"column:MA104;comment:;"`  //MA104字段 
      MA105  string `json:"MA105" form:"MA105" gorm:"column:MA105;comment:;size:20;"`  //MA105字段 
      MA106  string `json:"MA106" form:"MA106" gorm:"column:MA106;comment:;size:1;"`  //MA106字段 
      MA107  string `json:"MA107" form:"MA107" gorm:"column:MA107;comment:;size:8;"`  //MA107字段 
      MA108  string `json:"MA108" form:"MA108" gorm:"column:MA108;comment:;size:30;"`  //MA108字段 
      MA109  *float64 `json:"MA109" form:"MA109" gorm:"column:MA109;comment:;"`  //MA109字段 
      MA110  *float64 `json:"MA110" form:"MA110" gorm:"column:MA110;comment:;"`  //MA110字段 
      MA111  *float64 `json:"MA111" form:"MA111" gorm:"column:MA111;comment:;"`  //MA111字段 
      MA112  string `json:"MA112" form:"MA112" gorm:"column:MA112;comment:;size:10;"`  //MA112字段 
      MA113  string `json:"MA113" form:"MA113" gorm:"column:MA113;comment:;size:1;"`  //MA113字段 
      MA114  string `json:"MA114" form:"MA114" gorm:"column:MA114;comment:;size:20;"`  //MA114字段 
      MAB01  string `json:"MAB01" form:"MAB01" gorm:"column:MAB01;comment:;size:1;"`  //MAB01字段 
      MA115  string `json:"MA115" form:"MA115" gorm:"column:MA115;comment:;size:6;"`  //MA115字段 
      UDF01  string `json:"UDF01" form:"UDF01" gorm:"column:UDF01;comment:;size:255;"`  //UDF01字段 
      UDF02  string `json:"UDF02" form:"UDF02" gorm:"column:UDF02;comment:;size:255;"`  //UDF02字段 
      UDF03  string `json:"UDF03" form:"UDF03" gorm:"column:UDF03;comment:;size:255;"`  //UDF03字段 
      UDF04  string `json:"UDF04" form:"UDF04" gorm:"column:UDF04;comment:;size:255;"`  //UDF04字段 
      UDF05  string `json:"UDF05" form:"UDF05" gorm:"column:UDF05;comment:;size:255;"`  //UDF05字段 
      UDF06  string `json:"UDF06" form:"UDF06" gorm:"column:UDF06;comment:;size:255;"`  //UDF06字段 
      UDF51  *float64 `json:"UDF51" form:"UDF51" gorm:"column:UDF51;comment:;"`  //UDF51字段 
      UDF52  *float64 `json:"UDF52" form:"UDF52" gorm:"column:UDF52;comment:;"`  //UDF52字段 
      UDF53  *float64 `json:"UDF53" form:"UDF53" gorm:"column:UDF53;comment:;"`  //UDF53字段 
      UDF54  *float64 `json:"UDF54" form:"UDF54" gorm:"column:UDF54;comment:;"`  //UDF54字段 
      UDF55  *float64 `json:"UDF55" form:"UDF55" gorm:"column:UDF55;comment:;"`  //UDF55字段 
      UDF56  *float64 `json:"UDF56" form:"UDF56" gorm:"column:UDF56;comment:;"`  //UDF56字段 
      UDF07  string `json:"UDF07" form:"UDF07" gorm:"column:UDF07;comment:;size:255;"`  //UDF07字段 
      UDF08  string `json:"UDF08" form:"UDF08" gorm:"column:UDF08;comment:;size:255;"`  //UDF08字段 
      UDF09  string `json:"UDF09" form:"UDF09" gorm:"column:UDF09;comment:;size:255;"`  //UDF09字段 
      UDF10  string `json:"UDF10" form:"UDF10" gorm:"column:UDF10;comment:;size:255;"`  //UDF10字段 
      UDF11  string `json:"UDF11" form:"UDF11" gorm:"column:UDF11;comment:;size:255;"`  //UDF11字段 
      UDF12  string `json:"UDF12" form:"UDF12" gorm:"column:UDF12;comment:;size:255;"`  //UDF12字段 
      UDF57  *float64 `json:"UDF57" form:"UDF57" gorm:"column:UDF57;comment:;"`  //UDF57字段 
      UDF58  *float64 `json:"UDF58" form:"UDF58" gorm:"column:UDF58;comment:;"`  //UDF58字段 
      UDF59  *float64 `json:"UDF59" form:"UDF59" gorm:"column:UDF59;comment:;"`  //UDF59字段 
      UDF60  *float64 `json:"UDF60" form:"UDF60" gorm:"column:UDF60;comment:;"`  //UDF60字段 
      UDF61  *float64 `json:"UDF61" form:"UDF61" gorm:"column:UDF61;comment:;"`  //UDF61字段 
      UDF62  *float64 `json:"UDF62" form:"UDF62" gorm:"column:UDF62;comment:;"`  //UDF62字段 
      MA200  *float64 `json:"MA200" form:"MA200" gorm:"column:MA200;comment:;"`  //MA200字段 
}


// TableName COPMA表 COPMA自定义表名 COPMA
func (COPMA) TableName() string {
  return "COPMA"
}

