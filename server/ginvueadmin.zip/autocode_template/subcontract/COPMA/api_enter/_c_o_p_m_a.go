package COPMA

type ApiGroup struct {
}
