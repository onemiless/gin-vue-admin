package COPMA


type ServiceGroup struct {
}

