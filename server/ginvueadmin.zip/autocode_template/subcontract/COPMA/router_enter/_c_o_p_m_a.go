package COPMA

type RouterGroup struct {
}
